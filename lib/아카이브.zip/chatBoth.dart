import 'dart:async';

import 'package:bubble/bubble.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'header.dart' as header;

import 'dart:convert';

class ChatScreen extends StatefulWidget {
  final DocumentSnapshot document;
  ChatScreen(this.document);

  _ChatScreenState createState() => _ChatScreenState(document);
}

class _ChatScreenState extends State<ChatScreen> with TickerProviderStateMixin {
  final List<ChatMessage> _message = <ChatMessage>[];
  final DocumentSnapshot document;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  TextEditingController _queryController = TextEditingController();
  ScrollController _scrollController = ScrollController();

  int curUserId;
  int oppoUserId;
  int chatUrl;

  double height;

  List curChatList = [];
  List oppoChatList = [];

  int lastReadIndex = 0;

  bool makeDone = false;
  _ChatScreenState(this.document);

  Stream<DocumentSnapshot> firebaseStream;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    curUserId = header.userArmyNum.hashCode;
    oppoUserId = document.data()['armyNum'].hashCode;
    if (curUserId >= oppoUserId) {
      chatUrl = curUserId - oppoUserId;
    } else {
      chatUrl = oppoUserId - curUserId;
    }
    isAlreadyExist();

    firebaseStream = FirebaseFirestore.instance
        .collection('chat')
        .doc('$chatUrl')
        .snapshots();

    //WidgetsBinding.instance
    //   .addPostFrameCallback((_) => _updateData());
  }

  void isAlreadyExist() async {
    await FirebaseFirestore.instance
        .collection('member')
        .doc(header.userId)
        .get()
        .then((DocumentSnapshot ds) {
      curChatList = ds.data()['chatList'];
    });

    await FirebaseFirestore.instance
        .collection('member')
        .doc(document.data()['id'])
        .get()
        .then((DocumentSnapshot ds) {
      oppoChatList = ds.data()['chatList'];
    });

    print('curchatList:' + '$curChatList');
    print('chatUrl: ' + '$chatUrl');
    if (curChatList.contains(chatUrl) || oppoChatList.contains(chatUrl)) return;

    FirebaseFirestore.instance
        .collection('chat')
        .doc('$chatUrl')
        .set({"whatSaid": []});

    curChatList.add(chatUrl);
    oppoChatList.add(chatUrl);
    FirebaseFirestore.instance
        .collection('member')
        .doc(header.userId)
        .update({'chatList': curChatList});
    FirebaseFirestore.instance
        .collection('member')
        .doc(document.data()['id'])
        .update({'chatList': oppoChatList});
  }

  void _alert([String text]) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialogs
        return AlertDialog(
          title: new Text("입력"),
          content: new Text(text ?? "아이디 혹은 비밀번호를 입력해주세요"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("닫기"),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }

  void _insertSingleItem(ChatMessage message) {
    //String contents = message.text;
    //_message.add(message);
    _message.insert(0, message);
    _listKey.currentState.insertItem(0);
  }

  void _getResponse() {
    if (_queryController.text.length > 0) {
      try {
        this._insertSingleItem(ChatMessage(
          text: _queryController.text,
          animationController: AnimationController(
            duration: Duration(milliseconds: 700),
            vsync: this,
          ),
        ));
      } catch (e) {
        print("Failed -> $e");
      } finally {
        _queryController.clear();
      }
    }
  }

  Widget _buildItem(ChatMessage item, Animation animation, int index) {
    String chatContent = item.text;
    bool mine;

    if (mine = chatContent.startsWith('<$curUserId>')) {
      chatContent = chatContent.replaceFirst('<$curUserId>', '');
    } else {
      chatContent = chatContent.replaceFirst('<$oppoUserId>', '');
    }
    print(chatContent);
    //print(chatContent);
    return SafeArea(
      child: SizeTransition(
          axisAlignment: 1.0,
          sizeFactor: animation,
          child: Padding(
            padding: EdgeInsets.only(top: 10),
            child: Container(
                alignment: mine ? Alignment.bottomRight : Alignment.bottomLeft,
                child: Bubble(
                  child: Text(chatContent),
                  color: mine ? Colors.blue : Colors.yellow,
                  padding: BubbleEdges.all(10),
                )),
          )),
    );
  }

  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    //print(MediaQuery.of(context).size.height);
    //print(height);
    print('build');
    List whatSaid = [];
    //scrollToEnd();
    print('afterCallback');
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(50.0),
        child: AppBar(
          //backgroundColor: Colors.white,
          leading: new IconButton(
            icon: new Icon(Icons.arrow_back, size: 30),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: Text(
            document.data()['name'] + "님 과의 대화" + '$chatUrl',
            textAlign: TextAlign.center,
          ),
        ),
      ),
      body: SafeArea(
          child: Column(
        children: [
          StreamBuilder<DocumentSnapshot>(
              stream: firebaseStream,
              builder: (context, snapshot) {
                print('streamBuilder builder');
                print(snapshot);
                print(snapshot.hasData);

                if (snapshot.hasData) {
                  print('snapshot on');
                  FirebaseFirestore.instance
                      .collection('chat')
                      .doc('$chatUrl')
                      .get()
                      .then((DocumentSnapshot ds) {
                    whatSaid = ds.data()['whatSaid'];

                    if (ds != null) {
                      for (var i = lastReadIndex;
                          i < whatSaid.length;
                          i++) {
                        _insertSingleItem(ChatMessage(
                          text: whatSaid[i] ?? '그런거 없쪙',
                          animationController: AnimationController(
                            duration: Duration(milliseconds: 700),
                            vsync: this,
                          ),
                        ));
                      }
                      print(whatSaid);
                      for (var j = 0; j < _message.length; j++)
                        print(_message[j].text);
                      lastReadIndex = (whatSaid.length);
                      //print(whatSaid.length - 1);
                    }
                    //return Future<String>
                  });
                }
                print('out of streamBuilder');
                return SizedBox(
                  height: height * 0.8,
                  child: AnimatedList(
                    controller: _scrollController,
                    shrinkWrap: true,
                    reverse: true,
                    key: _listKey,
                    itemBuilder: (BuildContext context, int index,
                        Animation<double> animation) {
                      print('buildItem');

                      return _buildItem(_message[index], animation, index);
                    },
                  ),
                );
              }),
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              height: 50,
              child: TextField(
                autofocus: true,
                decoration: InputDecoration(
                  icon: Icon(
                    Icons.message,
                    color: Colors.greenAccent,
                  ),
                  hintText: "채팅을 입력해주세요.",
                ),
                controller: _queryController,
                textInputAction: TextInputAction.send,
                onSubmitted: (msg) {
                  _queryController.text =
                      '<$curUserId>' + _queryController.text;
                  whatSaid.add(_queryController.text);
                  //this._getResponse();
                  _queryController.clear();
                  FirebaseFirestore.instance
                      .collection('chat')
                      .doc('$chatUrl')
                      .update({"whatSaid": whatSaid});
                },
              ),
            ),
          ),
        ],
      )),
    );
  }
}

class ChatMessage extends StatelessWidget {
  final String text; // 출력할 메시지
  final AnimationController animationController; // 리스트뷰에 등록될 때 보여질 효과

  ChatMessage({this.text, this.animationController});

  @override
  Widget build(BuildContext context) {
    // 위젯에 애니메이션을 발생하기 위해 SizeTransition을 추가
    return SafeArea(
      child: SizeTransition(
        // 사용할 애니메이션 효과 설정
        sizeFactor:
            CurvedAnimation(parent: animationController, curve: Curves.easeOut),
        axisAlignment: 0.0,
        // 리스트뷰에 추가될 컨테이너 위젯
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 10.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: const EdgeInsets.only(right: 16.0),
                // 사용자명의 첫번째 글자를 서클 아바타로 표시
                child: CircleAvatar(child: Text(header.userName[0])),
              ),
              Expanded(
                // 컬럼 추가
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    // 사용자명을 subhead 테마로 출력
                    Text(header.userName,
                        style: Theme.of(context).textTheme.subtitle1),
                    // 입력받은 메시지 출력
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: Text(text),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
